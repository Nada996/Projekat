const express = require("express")
const Oprema =require("../moduels/Oprema");

const router = express.Router()

const urlParser = require("body-parser");
const naruci = require("../moduels/naruci");

router.use(urlParser.urlencoded({
    extended: true
}));




router.get('/DodajRobu', (req, res) => {
  res.render('NovaRoba');
});
router.post('/',(req,res)=>{
  var item ={
      ime:req.body.ime,
      velicina:req.body.velicina,
     
      cena:req.body.cena,
      slika: req.body.link
  };
  console.log(item);
  let NovaRoba = new Oprema(item);
  NovaRoba.save((err, NovaRoba) => {
      if (err) {
        console.log(err);
      } else {
        console.log(NovaRoba);
        res.redirect('/admin/');
      }
    });
})

router.get('/', (req, res) => {
  naruci.find().exec(function (err, narudzbine) {
      if (err) {
          console.log(err);
      }
      else {
          console.log(narudzbine);
          res.render('admin', { narudzbine: narudzbine });
      }
  });
});

router.post('/:id', (req, res) => {
  let Delete = req.params.id;
  console.log(Delete);
  naruci.findByIdAndDelete(Delete, (err, response) => {
      if (err) {
          console.log(err);
      } else {
          naruci.find().exec(function (err, narudzbine) {
              if (err) {
                  console.log(err);
              }
              else {
                  console.log(narudzbine);
                  res.render('admin', { narudzbine: narudzbine });
              }
          });
      }
  });
});

  module.exports = router