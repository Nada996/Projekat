const express = require("express");

const router = express.Router();
const O = require("../moduels/Oprema");
const narudzbina = require("../moduels/naruci");

const mongoose = require("mongoose");
const urlParser = require("body-parser");
const naruci = require("../moduels/naruci");


router.use(urlParser.json())
router.use(urlParser.urlencoded({
  extended: true
}));


mongoose.connect("mongodb://localhost:27017/testdb", {
  useNewUrlParser: true,
   useUnifiedTopology: true
})
mongoose.connection.on("error", err => {
  console.log("err", err)
})
mongoose.connection.on("connected", (err, res) => {
  console.log("mongoose is connected")
})


router.get('/', (req, res) => {
  O.find().exec(function(err,Oprema){
    if(err){
      console.log(err);
    }
    else{
      console.log("Oprema " + Oprema);
      res.render('index',{Oprema:Oprema});
    }
  });
});

router.get('/narudzbina/:ime',(req,res)=>{
  O.findOne({ime: req.params.ime}).exec(function(err,Oprema){
    if(err){
      console.log(err);
    }
    else{
      console.log("Narudzbina " );
      res.render('narudzbina',{Oprema:Oprema});
    }
  });
});

router.post('/narudzbina/:ime',(req,res)=>{
  var naziv= req.params.ime;
  
  console.log("Uspesno naruceno:  "  +  naziv);
  var item = {
    broj:req.body.brTelefona,
    ime:req.body.imeIprezime,
    adresa: req.body.adresa,
    adresa2:req.body.adresa2,
    grad:req.body.grad,
  
    drzava:req.body.drzava,
    velicina:req.body.velicina,
    pb: req.body.zip,
   
    naziv:req.params.ime,
    
  };

  let narudzbina = new naruci(item);
  narudzbina.save((err,naruci) => {
    if (err) {
      console.log(err);
    } else {
      console.log(narudzbina);
      res.redirect('/');
    }
  });

});



module.exports = router;
