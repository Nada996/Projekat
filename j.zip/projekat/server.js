const express = require("express");
const oprema = require("./routes/oprema");
const admin = require("./routes/admin");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");
const { join } = require("path");

const PORT = 3000;



app.use(cors());
app.use(bodyParser.json());

app.set('/views',express.static(path.join(__dirname,'static')));
app.set('view engine','ejs')
app.use(express.static(path.join(__dirname,"public")));

app.use("/", oprema)
app.use("/admin",admin)
app.listen(PORT, function() {
  console.log("Server running on localhost:" + PORT);
  
});
