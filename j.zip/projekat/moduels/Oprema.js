const mongoose = require('mongoose');

const Schema = mongoose.Schema;
const OpremaShema = new Schema({
  
  ime: String,
velicina:String,

  cena: String,
  slika: String,
},{
  collection:'Oprema'
});

module.exports = mongoose.model("Oprema",OpremaShema,"Oprema");